# EV Hunter

Interactive EV comparison dashboard focused on Bengaluru and Hyderabad.

## Features
- City and on-road budget filtering
- Search, range, speed, removable-battery filters
- Variant-level comparison
- Personal value score
- Running-cost calculator
- 5-year ownership estimate
- Side-by-side comparison
- Responsive mobile-first UI

## Run locally
npm install
npm run dev

## Data
The bundled dataset is an initial research dataset. Prices and specifications should be re-verified against manufacturer/dealer sources before making a purchase decision.
